
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was uflibConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

get_filename_component(uflib_CMAKE_DIR "${CMAKE_CURRENT_LIST_FILE}" PATH)

include(CMakeFindDependencyMacro)

find_dependency(OpenSSL)

# Valgrind is optional — standard_valgrind_includes.h conditionally includes it.
find_path(VALGRIND_INCLUDE_DIR valgrind/valgrind.h
    HINTS /opt/include /usr/include /usr/local/include
)

list(APPEND CMAKE_MODULE_PATH ${uflib_CMAKE_DIR})

include("${uflib_CMAKE_DIR}/uflibTargets.cmake")

# Create canonical alias uflib::uflib — resolves to whichever target was built.
# BUILD_SHARED_LIBS=ON  → uflib::uflib_shared (preferred, dynamic linking)
# BUILD_SHARED_LIBS=OFF → uflib::uflib_static
if(NOT TARGET uflib::uflib)
    if(TARGET uflib::uflib_shared)
        add_library(uflib::uflib ALIAS uflib::uflib_shared)
    elseif(TARGET uflib::uflib_static)
        add_library(uflib::uflib ALIAS uflib::uflib_static)
    else()
        message(FATAL_ERROR "Neither uflib::uflib_shared nor uflib::uflib_static found in uflibTargets.cmake")
    endif()
endif()

set(uflib_LIBRARIES uflib::uflib)
