/**
 */

#ifndef UFLIB_DB_DB_SQL_H
#define UFLIB_DB_DB_SQL_H

#include <uflib/uflib_defs.h>

#include <time.h>
#include <stdint.h>
#include <stdbool.h>
#include <uflib/exponential_backoff/exponential_backoff_type.h>
#include <mariadb/mysql.h>

#ifdef _HOEL_SQLITE
#define HOEL_DB_TYPE_SQLITE  0
#endif

#define HOEL_DB_TYPE_MARIADB 1

#ifdef _HOEL_PGSQL
#define HOEL_DB_TYPE_PGSQL   2
#endif

#define HOEL_COL_TYPE_INT    0
#define HOEL_COL_TYPE_DOUBLE 1
#define HOEL_COL_TYPE_TEXT   2
#define HOEL_COL_TYPE_DATE   3
#define HOEL_COL_TYPE_BLOB   4
#define HOEL_COL_TYPE_NULL   5

#define H_OK                0  // No error
#define H_ERROR             1  // Generic error
#define H_ERROR_PARAMS      2  // Error in input parameters
#define H_ERROR_CONNECTION  3  // Error in database connection
#define H_ERROR_QUERY       4  // Error executing query
#define H_ERROR_MEMORY      99 // Error allocating memory

#define H_OPTION_NONE   0x0000 // Nothing whatsoever
#define H_OPTION_SELECT 0x0001 // Execute a SELECT statement
#define H_OPTION_EXEC   0x0010 // Execute an INSERT, UPDATE or DELETE statement

#define MYSQL_HANDLE(x)	(((struct _h_mariadb *)x->connection)->db_handle)

/**
 * handle container
 */
struct _h_connection {
  int type;
  void * connection;
  ExponentialBackoffDescriptor backoff_descriptor;
};

typedef struct _h_connection DbBackend;

/**
 * sql value integer type
 */
struct _h_type_int {
  uint64_t value;
};

/**
 * sql value double type
 */
struct _h_type_double {
  double value;
};

/**
 * sql value date/time type
 */
struct _h_type_datetime {
  struct tm value;
};

/**
 * sql value string type
 */
struct _h_type_text {
  size_t length;
  char * value;
};

/**
 * sql value blob type
 */
struct _h_type_blob {
  size_t length;
  void * value;
};

/**
 * sql data container
 */
struct _h_data {
  int type;
  void * t_data;
};

/**
 * sql result structure
 */
struct _h_result {
  unsigned int nb_rows;
  unsigned int nb_columns;
  struct _h_data ** data;
};

/**
 * AA+
 * Abstraction around statement object
 */
struct _h_statement {
    void * t_data;
};

#define AS_MARIADB_STATEMENT(x) ((MYSQL_STMT *)(x))

PUBLIC_API void InitMysql (void);
struct _h_connection *InitialiseDbBackend (void);
PUBLIC_API void SqlServerDisplayConnectedUsers (struct _h_connection *db_ptr);

/**
 * Close a database connection
 * return H_OK on success
 */
PUBLIC_API __attribute_used__ int h_close_db(struct _h_connection * conn);

/**
 * h_escape_string
 * Escapes a string
 * returned value must be free'd after use
 */
PUBLIC_API __attribute_used__ char * h_escape_string(const struct _h_connection * conn, const char * unsafe);

/**
 * h_execute_query
 * Execute a query, set the result structure with the returned values if available
 * if result is NULL, the query is executed but no value will be returned
 * options available
 * H_OPTION_NONE (0): no option
 * H_OPTION_SELECT: Execute a prepare statement (sqlite only)
 * H_OPTION_EXEC: Execute an exec statement (sqlite only)
 * return H_OK on success
 */
PUBLIC_API int h_execute_query(struct _h_connection * conn, const char * query, struct _h_result * result, int options);

/**
 * h_query_insert
 * Execute an insert query
 * return H_OK on success
 */
PUBLIC_API int h_query_insert(struct _h_connection * conn, const char * query);

/**
 * h_query_last_insert_id
 * return the id of the last inserted value
 * return a pointer to `struct _h_data *` on success, NULL otherwise.
 */
struct _h_data * h_query_last_insert_id(struct _h_connection * conn);

/**
 * h_query_update
 * Execute an update query
 * return H_OK on success
 */
PUBLIC_API int h_query_update(struct _h_connection * conn, const char * query);

/**
 * h_query_delete
 * Execute an delete query
 * return H_OK on success
 */
PUBLIC_API int h_query_delete(struct _h_connection * conn, const char * query);

/**
 * h_query_select
 * Execute a select query, set the result structure with the returned values
 * return H_OK on success
 */
PUBLIC_API int h_query_select(struct _h_connection * conn, const char * query, struct _h_result * result);

#if 0
/**
 * h_execute_query_json
 * Execute a query, set the returned values in the json result
 * return H_OK on success
 */
PUBLIC_API int h_execute_query_json(const struct _h_connection * conn, const char * query, json_t ** j_result);

/**
 * h_query_select_json
 * Execute a select query, set the returned values in the json results
 * return H_OK on success
 */
PUBLIC_API int h_query_select_json(const struct _h_connection * conn, const char * query, json_t ** j_result);

/**
 * json queries
 * The following functions run a sql query based on a json_t * object for input parameters
 * The input parameter is called j_query
 * If the j_query is well-formed, the query is executed and if available and specified, the result is stored into the j_result object. j_result must be decref'd after use
 * Also, the sql query generated is stored into generated_query if specified, generated_query must be free'd after use
 * The query execution result is returned by the function
 * 
 * A j_query has the following form
 * {
 *   "table": "table_name"             // String, mandatory, the table name where the query is executed
 *   "columns": ["col1", "col2"]       // Array of strings, available for h_select, optional. If not specified,will be used
 *   "order_by": "col_name [asc|desc]" // String, available for h_select, specify the order by clause, optional
 *   "limit": integer_value            // Integer, available for h_select, specify the limit value, optional
 *   "offset"                          // Integer, available for h_select, specify the limit value, optional but available only if limit is set
 *   "values": [{                      // json object or json array of json objects, available for h_insert, mandatory, specify the values to update
 *     "col1": "value1",               // Generates col1='value1' for an update query
 *     "col2": value_integer,          // Generates col2=value_integer for an update query
 *     "col3", "value3",               // Generates col3='value3' for an update query
 *     "col4", null                    // Generates col4=NULL for an update query
 *   }]
 *   "set": {                          // json object, available for h_update, mandatory, specify the values to update
 *     "col1": "value1",               // Generates col1='value1' for an update query
 *     "col2": value_integer,          // Generates col2=value_integer for an update query
 *     "col3", "value3",               // Generates col3='value3' for an update query
 *     "col4", null                    // Generates col4=NULL for an update query
 *   }
 *   "where": {                        // json object, available for h_select, h_update and h_delete, mandatory, specify the where clause. All clauses are separated with an AND operator
 *     "col1": "value1",               // Generates col1='value1'
 *     "col2": value_integer,          // Generates col2=value_integer
 *     "col3": null,                   // Generates col3=NULL
 *     "col4", {                       // Generates col4<12
 *       "operator": "<",
 *       "value": 12
 *     },
 *     "col5", {                       // Generates col5 IS NOT NULL
 *       "operator": "NOT NULL"
 *     },
 *     "col6", {                       // Generates col6 LIKE '%value6%'
 *       "operator": "raw",
 *       "value": "LIKE '%value6%'"
 *     }
 *   }
 * }
 */
#endif
#if 0
/**
 * h_select
 * Execute a select query
 * Uses a json_t * parameter for the query parameters
 * Store the result of the query in j_result if specified. j_result must be decref'd after use
 * Duplicate the generated query in generated_query if specified, must be free'd after use
 * return H_OK on success
 */
PUBLIC_API int h_select(const struct _h_connection * conn, const json_t * j_query, json_t ** j_result, char ** generated_query);

/**
 * h_insert
 * Execute an insert query
 * Uses a json_t * parameter for the query parameters
 * Duplicate the generated query in generated_query if specified, must be free'd after use
 * return H_OK on success
 */
PUBLIC_API int h_insert(const struct _h_connection * conn, const json_t * j_query, char ** generated_query);

/**
 * h_last_insert_id
 * return the id of the last inserted value
 * return a pointer to `json_t *` on success, NULL otherwise.
 * The returned value is of type JSON_INTEGER
 */
PUBLIC_API json_t * h_last_insert_id(const struct _h_connection * conn);
#endif

#if 0
/**
 * h_update
 * Execute an update query
 * Uses a json_t * parameter for the query parameters
 * Duplicate the generated query in generated_query if specified, must be free'd after use
 * return H_OK on success
 */
PUBLIC_API int h_update(const struct _h_connection * conn, const json_t * j_query, char ** generated_query);

/**
 * h_delete
 * Execute a delete query
 * Uses a json_t * parameter for the query parameters
 * Duplicate the generated query in generated_query if specified, must be free'd after use
 * return H_OK on success
 */
PUBLIC_API int h_delete(const struct _h_connection * conn, const json_t * j_query, char ** generated_query);
#endif

/**
 * Add a new struct _h_data * to an array of struct _h_data *, which already has cols columns
 * return H_OK on success
 */
PUBLIC_API int h_row_add_data(struct _h_data ** result, struct _h_data * data, int cols);

/**
 * Add a new row of struct _h_data * in a struct _h_result *
 * return H_OK on success
 */
PUBLIC_API int h_result_add_row(struct _h_result * result, struct _h_data * row, int rows);

/**
 * Allocate memory for a new struct _h_data * containing an int
 * return pointer to the new structure
 * return NULL on error
 */
struct _h_data * h_new_data_int(const uint64_t value);

/**
 * Allocate memory for a new struct _h_data * containing a double
 * return pointer to the new structure
 * return NULL on error
 */
struct _h_data * h_new_data_double(const double value);

/**
 * Allocate memory for a new struct _h_data * containing a text
 * return pointer to the new structure
 * return NULL on error
 */
struct _h_data * h_new_data_text(const char * value, const size_t length);

/**
 * Allocate memory for a new struct _h_data * containing a blob
 * return pointer to the new structure
 * return NULL on error
 */
struct _h_data * h_new_data_blob(const void * value, const size_t length);

/**
 * Allocate memory for a new struct _h_data * containing a date time structure
 * return pointer to the new structure
 * return NULL on error
 */
struct _h_data * h_new_data_datetime(const struct tm * datetime);

/**
 * Allocate memory for a new struct _h_data * containing a null value
 * return pointer to the new structure
 * return NULL on error
 */
struct _h_data * h_new_data_null();

/**
 * h_clean_result
 * Free all the memory allocated by the struct _h_result
 * return H_OK on success
 */
PUBLIC_API int h_clean_result(struct _h_result * result);

struct _h_statement *h_statement_prepare(struct _h_connection *conn, const char *sql_statement, size_t sql_statement_sz);

typedef int (*default_finaliser)(struct _h_result *);
typedef void (*default_query_provider_finaliser)(char *);

PUBLIC_API default_finaliser GetDefaultDbOpResultFinaliser();

PUBLIC_API default_query_provider_finaliser GetDefaultQueryStatementProviderFinalser();

/**
 * h_clean_data
 * Free memory allocated by the struct _h_data
 * return H_OK on success
 */
PUBLIC_API int h_clean_data(struct _h_data * data);

/**
 * h_clean_data_full
 * Free memory allocated by the struct _h_data and the struct _h_data pointer
 * return H_OK on success
 */
PUBLIC_API int h_clean_data_full(struct _h_data * data);

/**
 * h_clean_connection
 * free memory allocated by the struct _h_connection
 * return H_OK on success
 */
PUBLIC_API __attribute_used__ int h_clean_connection(struct _h_connection * conn);

/**
 * trim_whitespace_and_double_quotes
 * Return the string without its beginning and ending whitespaces or double quotes
 */
PUBLIC_API char * trim_whitespace_and_double_quotes(char *str);

#ifdef _HOEL_SQLITE
/**
 * h_connect_sqlite
 * Opens a database connection to a sqlite3 db file
 * return pointer to a struct _h_connection * on sucess, NULL on error
 */
struct _h_connection * h_connect_sqlite(const char * db_path);

/**
 * close a sqlite3 connection
 */
PUBLIC_API void h_close_sqlite(struct _h_connection * conn);

/**
 * escape a string
 * returned value must be free'd after use
 */
PUBLIC_API char * h_escape_string_sqlite(const struct _h_connection * conn, const char * unsafe);

/**
 * Return the id of the last inserted value
 */
PUBLIC_API int h_last_insert_id_sqlite(const struct _h_connection * conn);

/**
 * h_select_query_sqlite
 * Execute a select query on a sqlite connection, set the result structure with the returned values
 * Should not be executed by the user because all parameters are supposed to be correct
 * if result is NULL, the query is executed but no value will be returned
 * Useful for SELECT statements
 * return H_OK on success
 */
PUBLIC_API int h_select_query_sqlite(const struct _h_connection * conn, const char * query, struct _h_result * result);

/**
 * h_exec_query_sqlite
 * Execute a query on a sqlite connection
 * Should not be executed by the user because all parameters are supposed to be correct
 * No result is returned, useful for single INSERT, UPDATE or DELETE statements
 * return H_OK on success
 */
PUBLIC_API int h_exec_query_sqlite(const struct _h_connection * conn, const char * query);

/**
 * h_execute_query_json_sqlite
 * Execute a query on a sqlite connection, set the returned values in the json result
 * Should not be executed by the user because all parameters are supposed to be correct
 * return H_OK on success
 */
PUBLIC_API int h_execute_query_json_sqlite(const struct _h_connection * conn, const char * query, json_t ** j_result);
#endif


/**
 * h_connect_mariadb
 * Opens a database connection to a mariadb server
 * return pointer to a struct _h_connection * on sucess, NULL on error
 */
struct _h_connection * h_connect_mariadb(const char * host, const char * user, const char * passwd, const char * db, const unsigned int port, const char * unix_socket);

//AA+
struct _h_connection *h_reconnect_mariadb_initialisable(struct _h_connection *conn_db, bool is_reinitialise);
PUBLIC_API unsigned int h_reconnect_mariadb(struct _h_connection *conn_db);

/**
 * close connection to database
 */
PUBLIC_API void h_close_mariadb(struct _h_connection * conn);

/**
 * escape a string
 * returned value must be free'd after use
 */
PUBLIC_API char * h_escape_string_mariadb(const struct _h_connection * conn, const char * unsafe);
PUBLIC_API char * h_escape_binary_string_mariadb(const struct _h_connection * conn, const char * unsafe, size_t unsafe_sz);
/**
 * Return the id of the last inserted value
 */
PUBLIC_API int h_last_insert_id_mariadb(const struct _h_connection * conn);
/**
 * h_execute_query_mariadb
 * Execute a query on a mariadb connection, set the result structure with the returned values
 * Should not be executed by the user because all parameters are supposed to be correct
 * if result is NULL, the query is executed but no value will be returned
 * return H_OK on success
 */
PUBLIC_API int h_execute_query_mariadb(struct _h_connection * conn, const char * query, struct _h_result * result);

#if 0
/**
 * h_execute_query_json_mariadb
 * Execute a query on a mariadb connection, set the returned values in the json result
 * Should not be executed by the user because all parameters are supposed to be correct
 * return H_OK on success
 */
PUBLIC_API int h_execute_query_json_mariadb(const struct _h_connection * conn, const char * query, json_t ** j_result);
#endif

/**
 * h_get_mariadb_value
 * convert value into a struct _h_data * depening on the m_type given
 * returned value must be free'd with h_clean_data_full after use
 */
struct _h_data * h_get_mariadb_value(const char * value, const unsigned long length, const int m_type);

MYSQL_STMT *h_statement_prepare_mariadb(struct _h_connection *conn, const char *sql_statement, size_t sql_statement_sz);

#ifdef _HOEL_PGSQL
/**
 * h_connect_pgsql
 * Opens a database connection to a PostgreSQL server
 * return pointer to a struct _h_connection * on sucess, NULL on error
 */
struct _h_connection * h_connect_pgsql(char * conninfo);

/**
 * h_execute_query_pgsql
 * Execute a query on a pgsql connection, set the result structure with the returned values
 * Should not be executed by the user because all parameters are supposed to be correct
 * if result is NULL, the query is executed but no value will be returned
 * return H_OK on success
 */
PUBLIC_API int h_execute_query_pgsql(const struct _h_connection * conn, const char * query, struct _h_result * result);

/**
 * h_execute_query_json_pgsql
 * Execute a query on a pgsql connection, set the returned values in the json results
 * Should not be executed by the user because all parameters are supposed to be correct
 * return H_OK on success
 */
PUBLIC_API int h_execute_query_json_pgsql(const struct _h_connection * conn, const char * query, json_t ** j_result);

/**
 * close a pgsql connection
 */
PUBLIC_API void h_close_pgsql(struct _h_connection * conn);

/**
 * escape a string
 * returned value must be free'd after use
 */
PUBLIC_API char * h_escape_string_pgsql(const struct _h_connection * conn, const char * unsafe);
#endif

#endif
