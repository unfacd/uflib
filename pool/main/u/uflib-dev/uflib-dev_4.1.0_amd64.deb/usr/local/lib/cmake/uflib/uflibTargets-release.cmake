#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "uflib::uflib_static" for configuration "Release"
set_property(TARGET uflib::uflib_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(uflib::uflib_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libuflib.a"
  )

list(APPEND _cmake_import_check_targets uflib::uflib_static )
list(APPEND _cmake_import_check_files_for_uflib::uflib_static "${_IMPORT_PREFIX}/lib/libuflib.a" )

# Import target "uflib::uflib_k12" for configuration "Release"
set_property(TARGET uflib::uflib_k12 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(uflib::uflib_k12 PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libuflib_k12.a"
  )

list(APPEND _cmake_import_check_targets uflib::uflib_k12 )
list(APPEND _cmake_import_check_files_for_uflib::uflib_k12 "${_IMPORT_PREFIX}/lib/libuflib_k12.a" )

# Import target "uflib::uflib_mjson" for configuration "Release"
set_property(TARGET uflib::uflib_mjson APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(uflib::uflib_mjson PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libuflib_mjson.a"
  )

list(APPEND _cmake_import_check_targets uflib::uflib_mjson )
list(APPEND _cmake_import_check_files_for_uflib::uflib_mjson "${_IMPORT_PREFIX}/lib/libuflib_mjson.a" )

# Import target "uflib::uflib_lzf" for configuration "Release"
set_property(TARGET uflib::uflib_lzf APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(uflib::uflib_lzf PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libuflib_lzf.a"
  )

list(APPEND _cmake_import_check_targets uflib::uflib_lzf )
list(APPEND _cmake_import_check_files_for_uflib::uflib_lzf "${_IMPORT_PREFIX}/lib/libuflib_lzf.a" )

# Import target "uflib::uflib_protobuf_c" for configuration "Release"
set_property(TARGET uflib::uflib_protobuf_c APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(uflib::uflib_protobuf_c PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libuflib_protobuf_c.a"
  )

list(APPEND _cmake_import_check_targets uflib::uflib_protobuf_c )
list(APPEND _cmake_import_check_files_for_uflib::uflib_protobuf_c "${_IMPORT_PREFIX}/lib/libuflib_protobuf_c.a" )

# Import target "uflib::zlog" for configuration "Release"
set_property(TARGET uflib::zlog APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(uflib::zlog PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libzlog.a"
  )

list(APPEND _cmake_import_check_targets uflib::zlog )
list(APPEND _cmake_import_check_files_for_uflib::zlog "${_IMPORT_PREFIX}/lib/libzlog.a" )

# Import target "uflib::uflib_quirc" for configuration "Release"
set_property(TARGET uflib::uflib_quirc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(uflib::uflib_quirc PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libuflib_quirc.a"
  )

list(APPEND _cmake_import_check_targets uflib::uflib_quirc )
list(APPEND _cmake_import_check_files_for_uflib::uflib_quirc "${_IMPORT_PREFIX}/lib/libuflib_quirc.a" )

# Import target "uflib::uflib_shared" for configuration "Release"
set_property(TARGET uflib::uflib_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(uflib::uflib_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libuflib.so.4.1.0"
  IMPORTED_SONAME_RELEASE "libuflib.so.4"
  )

list(APPEND _cmake_import_check_targets uflib::uflib_shared )
list(APPEND _cmake_import_check_files_for_uflib::uflib_shared "${_IMPORT_PREFIX}/lib/libuflib.so.4.1.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
