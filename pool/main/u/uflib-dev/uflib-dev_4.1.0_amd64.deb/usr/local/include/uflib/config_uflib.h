/**
 * Copyright (C) 2015-2026 unfacd works
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * @file config_uflib.h.in
 * @brief CMake configure_file() template — generates config_uflib.h at configure time.
 */

#ifndef CONFIG_UFLIB_H
#define CONFIG_UFLIB_H

#define _REENTRANT
#ifndef _GNU_SOURCE
# define _GNU_SOURCE
#endif

#define UF_DEBUG_BUILD  0   /* 1 when CMAKE_BUILD_TYPE=Debug, or when a verbosity level is on */
#define UF_DEBUG_BUILD_L2 0    /* level-2 verbose tracing */
#define UF_DEBUG_BUILD_L3 0    /* level-3 per-object tracing */

/* Build-time capabilities.  Every capability the build understands appears
 * here, and every one is off unless the build asks for it:
 *
 *   cmake -DUFLIB_CAPABILITY_HIREDIS=ON …     the config module's Redis driver
 *   cmake -DUFLIB_CAPABILITY_SQL=ON …         the config module's SQL driver
 *   cmake -DUFLIB_CAPABILITY_SQLITE=ON …      the config module's SQLite driver
 *   cmake -DUFLIB_CAPABILITY_QUIRC=ON …       QR-code reading
 *   cmake -DUFLIB_CAPABILITY_QRENCODE=ON …    QR-code rendering
 *   cmake -DUFLIB_CAPABILITY_UTF8PROC=ON …    the utf8proc-backed UTF-8 helpers
 *   cmake -DUFLIB_CAPABILITY_K12=ON …         the KangarooTwelve hash
 *   cmake -DUFLIB_CAPABILITY_LZF=ON …         lzf compression
 *   cmake -DUFLIB_CAPABILITY_MJSON=ON …       the JSON parser
 *   cmake -DUFLIB_CAPABILITY_PROTOBUF_C=ON …  the protobuf-c runtime
 *   cmake -DUFLIB_CAPABILITY_ZLOG=ON …        the logger's backend
 *
 * A build names what it carries.
 *
 * `#cmakedefine` rather than `#define`, so a capability that is off leaves the
 * macro *undefined* instead of defined to 0.  Both read as false in `#if`, but
 * only this form is also right under `#ifdef` — and an author reaching for
 * `#ifdef` should not have to know which of the two was used.
 *
  */
#define UFLIB_CAPABILITY_HIREDIS 1
#define UFLIB_CAPABILITY_SQL 1
/* #undef UFLIB_CAPABILITY_SQLITE */
#define UFLIB_CAPABILITY_QUIRC 1
#define UFLIB_CAPABILITY_QRENCODE 1
#define UFLIB_CAPABILITY_UTF8PROC 1
#define UFLIB_CAPABILITY_K12 1
#define UFLIB_CAPABILITY_LZF 1
#define UFLIB_CAPABILITY_MJSON 1
#define UFLIB_CAPABILITY_PROTOBUF_C 1
#define UFLIB_CAPABILITY_ZLOG 1

#include <uflib/config_defs_uflib.h>

#endif /* CONFIG_H */
